Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/fa598f4971aef0d9a739a3e74339a9d2607dffc4>
