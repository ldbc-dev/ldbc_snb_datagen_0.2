Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/d543f78b5da8ee8f46f28c203af54516ee9f7e12>
