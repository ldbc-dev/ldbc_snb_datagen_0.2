Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/2b440bb32ea4020588ceffed5b91986d20d4f875>
