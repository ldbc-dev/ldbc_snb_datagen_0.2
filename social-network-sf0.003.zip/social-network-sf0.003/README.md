Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/4bbd99c5a10750c28780ed55ea5b38b1362d7341>
