Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/d6862401b42fe2b6c7482601532becd6f3fff71f>
