Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/ae9420ad019a4a2160c98ca7f43516002fbafe6f>
