Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/7fad87ac015cb0e4f2f0c78cc78e242a17a2d3ee>
