Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/4695b566ca7a67f38020124bb8e0d27f68549039>
