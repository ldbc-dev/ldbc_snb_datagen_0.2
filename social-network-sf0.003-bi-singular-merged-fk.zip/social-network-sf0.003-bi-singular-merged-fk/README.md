Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/8cdd4f12531259d4b76467b3c275858d6dedeec3>
