Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/0342a8c10babe56e7b9f2a61301c9561be4785d3>
