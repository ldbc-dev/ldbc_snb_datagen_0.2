Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/35b93722418fc6ee0a55a0678702294069374df0>
