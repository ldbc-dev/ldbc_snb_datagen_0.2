Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/ea08414484af15aef8915ff0da0bc688463cc349>
