Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/cdda13064b46e17bc24811060d10be81a895f55b>
