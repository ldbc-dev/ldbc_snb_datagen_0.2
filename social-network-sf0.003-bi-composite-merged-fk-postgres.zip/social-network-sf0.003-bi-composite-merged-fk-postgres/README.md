Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/328b94e0c8c03fa4721a38bc07392b02c7b0b641>
