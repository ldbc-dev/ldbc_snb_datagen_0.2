Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/b2ee74d317ab1b880dbd744610b6aef920ddaa17>
